SOKOLINK ANDROID APP PROJECT

This project wraps the current SokoLink marketplace prototype in an Android app shell. It is source code, not a compiled APK yet.

BUILD WITHOUT A COMPUTER (using your phone and GitHub's cloud builder):
1. Sign in or create an account at https://github.com.
2. Create a new repository named SokoLink. For easiest setup, choose Public (or use a private repo if you know how to enable Actions for it).
3. On the new repository page, choose Add file > Upload files.
4. Extract this ZIP on your phone first, then upload the CONTENTS of the SokoLinkAndroid folder (including the hidden .github folder if your file picker shows hidden files). The .github/workflows/build-apk.yml file is what starts the cloud build.
5. Commit the uploaded files to the main branch.
6. Open the repository's Actions tab, choose “Build SokoLink APK”, and tap Run workflow if it has not started automatically.
7. When the run succeeds, open it and download the “SokoLink-debug-APK” artifact. GitHub may download it as a ZIP; extract it to find app-debug.apk.
8. Tap app-debug.apk to install it. Android may ask you to allow installs from your browser or file manager. Only install APKs you built from source you trust.

LIMITATIONS:
- This is a prototype wrapped as an Android app, not a production marketplace.
- Products/orders are not yet synchronized between different users.
- M-Pesa is not connected; no live payments are processed.
- Before public launch, the app needs secure backend/database, real authentication, verified payment callbacks, seller/admin controls, privacy policy, testing, and a properly signed release build.
